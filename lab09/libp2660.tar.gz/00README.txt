Physics 2660 code library
Version 0

This is a very simple version of a histogram and random number
generator library.

You can download all the code by fetching the tar file inthis directory.

Use the make.sh to build the library and test program.  A Makefile
is also included, but this is only included as an example for the 
curious.  They can be a surprisingly complex topic.

To learn more about proper Makefiles see for example:
http://www.gnu.org/software/make/manual/make.html

All file can be downloaded from the tarfile in this directory.
